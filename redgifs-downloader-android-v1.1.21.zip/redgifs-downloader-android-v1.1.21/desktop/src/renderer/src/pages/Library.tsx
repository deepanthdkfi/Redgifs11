import { useCallback, useDeferredValue, useEffect, useMemo, useState } from 'react'
import PageHeader from '../components/PageHeader'
import ViewToggle from '../components/ViewToggle'
import Dropdown from '../components/Dropdown'
import FeedGrid from '../components/FeedGrid'
import EmptyState from '../components/EmptyState'
import FeedState from '../components/FeedState'
import { useViewMode } from '../hooks/useViewMode'
import { useDownload } from '../hooks/useDownload'
import { usePlayer } from '../player/PlayerProvider'
import { useBlockedTags } from '../context/blockedTags'
import { useNotify } from '../context/notify'
import { readCache, writeCache } from '../lib/cache'
import type { Collection, Content, LibraryProgress } from '@shared/types'

type SourceSel = 'all' | 'liked' | string // string = collection id
type SortKey = 'recent' | 'likes' | 'views' | 'duration' | 'az'

const SORTS: { key: SortKey; label: string }[] = [
  { key: 'recent', label: 'Newest' },
  { key: 'likes', label: 'Most liked' },
  { key: 'views', label: 'Most viewed' },
  { key: 'duration', label: 'Longest' },
  { key: 'az', label: 'Creator A–Z' }
]

// Cards rendered initially / added per scroll step — the index can hold
// thousands of gifs, and mounting them all at once locks the page up.
const RENDER_BATCH = 60

const comparators: Record<SortKey, (a: Content, b: Content) => number> = {
  recent: (a, b) => b.createDate - a.createDate,
  likes: (a, b) => b.likes - a.likes,
  views: (a, b) => b.views - a.views,
  duration: (a, b) => (b.duration || 0) - (a.duration || 0),
  az: (a, b) => a.username.localeCompare(b.username)
}

/**
 * Library → the local, offline-searchable index of every gif cached from the
 * user's collections and liked videos. A "Reindex" pass walks the whole library
 * via the RedGifs API and stores metadata; this page then searches/sorts across
 * all of it instantly, with no network per query.
 */
export default function Library(): JSX.Element {
  const notify = useNotify()
  const player = usePlayer()
  const { isBlocked } = useBlockedTags()
  const download = useDownload()
  const [mode, setMode] = useViewMode('library', 'grid')

  const [collections, setCollections] = useState<Collection[]>(
    () => readCache<Collection[]>('library:collections') ?? []
  )
  const [source, setSource] = useState<SourceSel>('all')
  const [sort, setSort] = useState<SortKey>('recent')
  const [query, setQuery] = useState('')

  const [all, setAll] = useState<Content[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [progress, setProgress] = useState<LibraryProgress | null>(null)

  // Load the collection list for the source picker (cache-first).
  useEffect(() => {
    window.api
      .getCollections()
      .then((list) => {
        setCollections(list)
        writeCache('library:collections', list)
      })
      // The source-picker list failing is independent of the cached content —
      // don't route it into the content error state (it would hide the
      // "index your library" onboarding and blank the grid).
      .catch(() => undefined)
  }, [])

  // Pull the cached gifs matching the current source out of local storage.
  const reload = useCallback((): void => {
    setLoading(true)
    setError(null)
    const filter =
      source === 'all'
        ? {}
        : source === 'liked'
          ? { likedOnly: true }
          : { sources: [{ type: 'collection' as const, id: source }] }
    window.api
      .searchCache(filter)
      .then((rows) => setAll(rows))
      // Clear the rows too, so a failed reload surfaces the error instead of
      // leaving the previous source's stale results on screen.
      .catch((e) => {
        setAll([])
        setError(e instanceof Error ? e.message : String(e))
      })
      .finally(() => setLoading(false))
  }, [source])

  useEffect(() => reload(), [reload])

  // Live progress while a reindex runs. Once a run finishes the readout must
  // hand back to the live result count — holding the final "Indexed N" line
  // forever would mask every later filter/search change.
  useEffect(() => {
    return window.api.on('evt:library:progress', (p) => setProgress(p.running ? p : null))
  }, [])

  const running = progress?.running ?? false

  const reindex = (): void => {
    if (running) return
    setProgress({
      phase: 'collections',
      collectionsDone: 0,
      collectionsTotal: 0,
      gifsCached: 0,
      currentLabel: 'Starting…',
      running: true
    })
    window.api
      .indexLibrary()
      .then((final) => {
        // The toast carries the summary; the readout returns to the count.
        setProgress(null)
        notify(`Indexed ${final.gifsCached} gifs`, 'success')
        reload()
      })
      .catch((e) => {
        setProgress(null)
        notify('Indexing failed: ' + (e instanceof Error ? e.message : String(e)), 'error')
      })
  }

  // Filtering thousands of rows per keystroke is fine; RENDERING them is not —
  // defer the query so typing stays responsive while the grid catches up.
  const deferredQuery = useDeferredValue(query)

  // Free-text + blocked-tag filter, then sort. Recomputed only when inputs move.
  const results = useMemo(() => {
    const terms = deferredQuery.toLowerCase().split(/\s+/).filter(Boolean)
    const filtered = all.filter((c) => {
      if (isBlocked(c)) return false
      if (!terms.length) return true
      const hay = (
        c.title +
        ' ' +
        c.description +
        ' ' +
        c.username +
        ' ' +
        (c.tags ?? []).join(' ')
      ).toLowerCase()
      return terms.every((t) => hay.includes(t))
    })
    return filtered.sort(comparators[sort])
  }, [all, deferredQuery, sort, isBlocked])

  // Incremental rendering: only a slice of the results is mounted; scrolling
  // near the end grows it. The player still receives the FULL result list, so
  // wheeling through clips isn't capped by what the grid has rendered.
  const [visibleCount, setVisibleCount] = useState(RENDER_BATCH)
  useEffect(() => {
    setVisibleCount(RENDER_BATCH)
  }, [source, sort, deferredQuery])
  const visible = useMemo(() => results.slice(0, visibleCount), [results, visibleCount])

  const open = (_c: Content, index: number): void => {
    player.open({ items: results, index, label: 'Library', loadMore: async () => [] })
  }

  // Genuinely unindexed: the unfiltered "all sources" view has nothing cached.
  // A zero under a narrower source or a query must read as "No matches" — not
  // re-run the onboarding pitch at someone whose library is already indexed.
  const unindexed =
    !loading && !error && all.length === 0 && source === 'all' && query.trim() === ''

  return (
    <div className="page">
      <PageHeader
        kicker="library"
        kickerIndex={9}
        title="All media"
        right={
          <div className="controls">
            <ViewToggle value={mode} onChange={setMode} />
          </div>
        }
      />

      <div className="toolbar">
        <input
          className="field-search"
          placeholder="Search cached gifs — name, creator, tag…"
          aria-label="Search cached gifs"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <Dropdown
          ariaLabel="Source"
          value={source}
          onChange={setSource}
          options={[
            { id: 'all', label: 'All sources' },
            { id: 'liked', label: 'Liked' },
            ...collections.map((c) => ({ id: c.id, label: c.name }))
          ]}
        />
        <Dropdown
          ariaLabel="Sort by"
          value={sort}
          onChange={(id) => setSort(id as SortKey)}
          options={SORTS.map((s) => ({ id: s.key, label: s.label }))}
        />
        <button className="btn btn-ember btn-sm" onClick={reindex} disabled={running}>
          {running ? 'Indexing…' : 'Reindex'}
        </button>
        <span className="readout">
          {progress?.running
            ? `${progress.phase === 'liked' ? 'Liked videos' : `Collections ${progress.collectionsDone}/${progress.collectionsTotal}`} · ${progress.gifsCached} cached${progress.currentLabel ? ` · ${progress.currentLabel}` : ''}`
            : `${results.length} ${results.length === 1 ? 'result' : 'results'}${source !== 'all' ? ' in this source' : ''}`}
        </span>
      </div>

      {unindexed ? (
        <EmptyState
          message="Nothing indexed yet"
          hint="Run a reindex to cache metadata for every gif in your collections and likes — then search and sort across your whole library, offline."
          action={
            <button className="btn btn-ember" onClick={reindex} disabled={running}>
              {running ? 'Indexing…' : 'Index my library'}
            </button>
          }
        />
      ) : (
        <>
          <FeedState
            loading={loading}
            error={error}
            isEmpty={results.length === 0}
            emptyMessage="No matches"
            emptyHint="Try a different search or source."
            onRetry={reload}
          />
          {results.length > 0 && (
            <FeedGrid
              items={visible}
              mode={mode}
              onOpen={open}
              onDownload={download}
              onEndReached={() => setVisibleCount((c) => c + RENDER_BATCH)}
              hasMore={visibleCount < results.length}
            />
          )}
        </>
      )}
    </div>
  )
}
